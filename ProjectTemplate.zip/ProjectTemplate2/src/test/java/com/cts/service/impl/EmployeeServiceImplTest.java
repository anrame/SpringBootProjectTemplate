package com.cts.service.impl;

import static org.mockito.ArgumentMatchers.any;

import java.time.Instant;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cts.dto.request.CreateEmployeeRequest;
import com.cts.dto.response.EmployeeResponse;
import com.cts.entity.Department;
import com.cts.entity.Employee;
import com.cts.exception.DepartmentNotFoundException;
import com.cts.repository.DepartmentRepository;
import com.cts.repository.EmployeeRepository;

@ExtendWith(MockitoExtension.class)
class EmployeeServiceImplTest {

	@Mock
	private EmployeeRepository employeeRepository;

	@Mock
	private DepartmentRepository departmentRepository;

	@InjectMocks
	private EmployeeServiceImpl employeeService;

	@Test
	void createEmployee_success() {

		Department dept = new Department();
		dept.setId(1L);
		dept.setName("IT");
		dept.setCreatedAt(Instant.now());

		Mockito.when(departmentRepository.findById(1L)).thenReturn(Optional.of(dept));

		Mockito.when(employeeRepository.save(any(Employee.class))).thenAnswer(invocation -> {
			Employee emp = invocation.getArgument(0);
			emp.setCreatedAt(Instant.now());
			emp.setUpdatedAt(Instant.now());
			return emp;
		});

		CreateEmployeeRequest request = new CreateEmployeeRequest();
		request.setName("Alice");
		request.setSalary(60000);
		request.setDepartmentId(1L);

		EmployeeResponse response = employeeService.createEmployee(request);

		Assertions.assertEquals("Alice", response.getName());
		Assertions.assertEquals("IT", response.getDepartmentName());
	}

	@Test
	void createEmployee_departmentNotFound() {

		Mockito.when(departmentRepository.findById(1L)).thenReturn(Optional.empty());

		CreateEmployeeRequest request = new CreateEmployeeRequest();
		request.setDepartmentId(1L);

		Assertions.assertThrows(DepartmentNotFoundException.class, () -> employeeService.createEmployee(request));
	}
}
