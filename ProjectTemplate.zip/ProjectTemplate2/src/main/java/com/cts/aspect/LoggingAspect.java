package com.cts.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Component
@Slf4j
public class LoggingAspect {

    @Before("execution(* com.cts.service.impl.*.*(..))")
    public void beforeService(JoinPoint jp) {
        log.info("SERVICE START: {}", jp.getSignature());
    }

    @AfterReturning("execution(* com.cts.controller.*.*(..))")
    public void afterController(JoinPoint jp) {
        log.info("CONTROLLER SUCCESS: {}", jp.getSignature());
    }
}