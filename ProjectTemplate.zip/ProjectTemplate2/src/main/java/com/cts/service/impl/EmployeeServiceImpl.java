package com.cts.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.cts.dto.request.CreateEmployeeRequest;
import com.cts.dto.request.UpdateEmployeeRequest;
import com.cts.dto.response.EmployeeResponse;
import com.cts.entity.Department;
import com.cts.entity.Employee;
import com.cts.exception.DepartmentNotFoundException;
import com.cts.exception.EmployeeNotFoundException;
import com.cts.mapper.EmployeeMapper;
import com.cts.repository.DepartmentRepository;
import com.cts.repository.EmployeeRepository;
import com.cts.service.EmployeeService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository employeeRepo;
    private final DepartmentRepository deptRepo;

    @Override
    public EmployeeResponse createEmployee(CreateEmployeeRequest req) {

        Department dept = deptRepo.findById(req.getDepartmentId())
                .orElseThrow(() -> new DepartmentNotFoundException("Department not found"));

        Employee emp = EmployeeMapper.toEntity(req, dept);
        employeeRepo.save(emp);

        return EmployeeMapper.toResponse(emp);
    }

    @Override
    public EmployeeResponse updateEmployee(Long id, UpdateEmployeeRequest req) {

        Employee emp = employeeRepo.findById(id)
                .orElseThrow(() -> new EmployeeNotFoundException("Employee not found"));

        emp.setName(req.getName());
        emp.setSalary(req.getSalary());
        employeeRepo.save(emp);

        return EmployeeMapper.toResponse(emp);
    }

    @Override
    public List<EmployeeResponse> getEmployeesByDept(Long deptId) {
        return employeeRepo.findByDepartmentId(deptId)
        		.stream()
                .map(EmployeeMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<EmployeeResponse> searchByName(String name) {
        return employeeRepo.searchNative(name)
        		.stream()
                .map(EmployeeMapper::toResponse)
        		.collect(Collectors.toList());
    }
}