package com.cts.service;

import java.util.List;

import com.cts.dto.request.CreateEmployeeRequest;
import com.cts.dto.request.UpdateEmployeeRequest;
import com.cts.dto.response.EmployeeResponse;

public interface EmployeeService {

    EmployeeResponse createEmployee(CreateEmployeeRequest req);

    EmployeeResponse updateEmployee(Long id, UpdateEmployeeRequest req);

    List<EmployeeResponse> getEmployeesByDept(Long deptId);

    List<EmployeeResponse> searchByName(String name);
}