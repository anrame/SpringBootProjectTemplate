package com.cts.service;

import java.util.List;

import com.cts.dto.request.CreateDepartmentRequest;
import com.cts.dto.response.DepartmentResponse;

public interface DepartmentService {

    DepartmentResponse createDepartment(CreateDepartmentRequest req);


    List<DepartmentResponse> getDepartments();

}