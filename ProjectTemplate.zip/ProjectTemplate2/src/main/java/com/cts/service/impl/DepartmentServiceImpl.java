package com.cts.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.cts.dto.request.CreateDepartmentRequest;
import com.cts.dto.response.DepartmentResponse;
import com.cts.entity.Department;
import com.cts.mapper.DepartmentMapper;
import com.cts.repository.DepartmentRepository;
import com.cts.service.DepartmentService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DepartmentServiceImpl implements DepartmentService {

    private final DepartmentRepository deptRepo;

    @Override
    public DepartmentResponse createDepartment(CreateDepartmentRequest req) {

        Department dept = DepartmentMapper.toEntity(req);
        deptRepo.save(dept);

        return DepartmentMapper.toResponse(dept);
    }


    @Override
    public List<DepartmentResponse> getDepartments() {
        return deptRepo.findAll()
        		.stream()
                .map(DepartmentMapper::toResponse)
                .collect(Collectors.toList());
    }

}