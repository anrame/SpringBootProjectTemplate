package com.cts.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class UpdateEmployeeRequest {

    @NotBlank
    @Size(min = 3, max = 50)
    private String name;

    @Positive
    private double salary;
}