package com.cts.dto.response;

import lombok.Data;

@Data
public class EmployeeResponse {
    private Long id;
    private String name;
    private double salary;
    private String departmentName;
    private String createdAt;
    private String updatedAt;
}