package com.cts.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class CreateDepartmentRequest {

    @NotBlank
    @Size(min = 3, max = 50)
    private String name;

}