package com.cts.dto.response;

import lombok.Data;

@Data
public class DepartmentResponse {
    private Long id;
    private String name;
   
    private String createdAt;
    private String updatedAt;
}