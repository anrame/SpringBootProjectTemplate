package com.cts.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class CreateEmployeeRequest {

    @NotBlank
    @Size(min = 3, max = 50)
    private String name;

    @Positive
    private double salary;

    @NotNull
    private Long departmentId;
}