package com.cts.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.api.APIResponse;
import com.cts.dto.request.CreateEmployeeRequest;
import com.cts.dto.request.UpdateEmployeeRequest;
import com.cts.dto.response.EmployeeResponse;
import com.cts.service.EmployeeService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/employees")
@Validated
public class EmployeeController {

    private final EmployeeService employeeService;

    @PostMapping
    public ResponseEntity<APIResponse<EmployeeResponse>> create(@Valid @RequestBody CreateEmployeeRequest req) {

        EmployeeResponse emp = employeeService.createEmployee(req);

        return ResponseEntity.ok(
                APIResponse.<EmployeeResponse>builder()
                        .status("SUCCESS")
                        .message("Employee Created")
                        .data(emp)
                        .build()
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<APIResponse<EmployeeResponse>> update(
            @PathVariable Long id,
            @Valid @RequestBody UpdateEmployeeRequest req) {

        EmployeeResponse emp = employeeService.updateEmployee(id, req);

        return ResponseEntity.ok(
                APIResponse.<EmployeeResponse>builder()
                        .status("SUCCESS")
                        .message("Employee Updated")
                        .data(emp)
                        .build()
        );
    }

    @GetMapping("/department/{deptId}")
    public ResponseEntity<APIResponse<List<EmployeeResponse>>> getByDept(
            @PathVariable Long deptId) {

        List<EmployeeResponse> result = employeeService.getEmployeesByDept(deptId);

        return ResponseEntity.ok(
                APIResponse.<List<EmployeeResponse>>builder()
                        .status("SUCCESS")
                        .message("Employees Retrieved")
                        .data(result)
                        .build()
        );
    }

    @GetMapping("/search")
    public ResponseEntity<APIResponse<List<EmployeeResponse>>> search(
            @RequestParam String name) {

        List<EmployeeResponse> result = employeeService.searchByName(name);

        return ResponseEntity.ok(
                APIResponse.<List<EmployeeResponse>>builder()
                        .status("SUCCESS")
                        .message("Search Results")
                        .data(result)
                        .build()
        );
    }
}