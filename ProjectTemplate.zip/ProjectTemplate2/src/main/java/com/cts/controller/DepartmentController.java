package com.cts.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.api.APIResponse;
import com.cts.dto.request.CreateDepartmentRequest;
import com.cts.dto.request.UpdateEmployeeRequest;
import com.cts.dto.response.DepartmentResponse;
import com.cts.dto.response.EmployeeResponse;
import com.cts.service.DepartmentService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/departments")
@Validated
public class DepartmentController {

    private final DepartmentService departmentService;

    @PostMapping
    public ResponseEntity<APIResponse<DepartmentResponse>> create(@Valid @RequestBody CreateDepartmentRequest req) {

    	DepartmentResponse dept = departmentService.createDepartment(req);

        return ResponseEntity.ok(
                APIResponse.<DepartmentResponse>builder()
                        .status("SUCCESS")
                        .message("Department Created")
                        .data(dept)
                        .build()
        );
    }

   

    @GetMapping
    public ResponseEntity<APIResponse<List<DepartmentResponse>>> getAll() {

        List<DepartmentResponse> result = departmentService.getDepartments();

        return ResponseEntity.ok(
                APIResponse.<List<DepartmentResponse>>builder()
                        .status("SUCCESS")
                        .message("Departments Retrieved")
                        .data(result)
                        .build()
        );
    }

   
}