package com.cts.mapper;

import com.cts.dto.request.CreateEmployeeRequest;
import com.cts.dto.response.EmployeeResponse;
import com.cts.entity.Department;
import com.cts.entity.Employee;

public class EmployeeMapper {

    public static Employee toEntity(CreateEmployeeRequest req, Department dept) {
        Employee e = new Employee();
        e.setName(req.getName());
        e.setSalary(req.getSalary());
        e.setDepartment(dept);
        return e;
    }

    public static EmployeeResponse toResponse(Employee emp) {
        EmployeeResponse res = new EmployeeResponse();
        res.setId(emp.getId());
        res.setName(emp.getName());
        res.setSalary(emp.getSalary());
        res.setDepartmentName(emp.getDepartment().getName());
        res.setCreatedAt(emp.getCreatedAt().toString());
        res.setUpdatedAt(emp.getUpdatedAt().toString());
        return res;
    }
}