package com.cts.mapper;

import com.cts.dto.request.CreateDepartmentRequest;
import com.cts.dto.response.DepartmentResponse;
import com.cts.entity.Department;

public class DepartmentMapper {

    public static Department toEntity(CreateDepartmentRequest req) {
        Department d = new Department();
        d.setName(req.getName());
    
        return d;
    }

    public static DepartmentResponse toResponse(Department dept) {
        DepartmentResponse res = new DepartmentResponse();
        res.setId(dept.getId());
        res.setName(dept.getName());
        res.setCreatedAt(dept.getCreatedAt().toString());
        res.setUpdatedAt(dept.getUpdatedAt().toString());
        return res;
    }
}