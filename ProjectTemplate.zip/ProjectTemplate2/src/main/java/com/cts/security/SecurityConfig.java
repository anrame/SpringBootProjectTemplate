package com.cts.security;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SecurityConfig {
    // Add your security configurations here later
}