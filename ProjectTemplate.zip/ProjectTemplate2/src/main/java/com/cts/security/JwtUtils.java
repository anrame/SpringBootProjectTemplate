package com.cts.security;

public class JwtUtils {
    // Placeholder for JWT utility methods
}