package com.cts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cts.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    List<Employee> findByDepartmentId(Long deptId);

    
//  JPQL
//    @Query("SELECT e FROM Employee e WHERE e.name LIKE %:name%")

//   Native SQL
    @Query(value = "SELECT * FROM employee WHERE name LIKE CONCAT('%', :name, '%')", nativeQuery = true)
    List<Employee> searchNative(@Param("name") String name);
}