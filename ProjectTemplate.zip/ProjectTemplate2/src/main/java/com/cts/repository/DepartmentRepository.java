package com.cts.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.entity.Department;

public interface DepartmentRepository extends JpaRepository<Department, Long> {}